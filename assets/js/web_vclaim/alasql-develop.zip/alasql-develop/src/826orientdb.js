if (alasql.options.orientdb) {
}
