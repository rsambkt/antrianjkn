# Prettyfier functions

alasql.pretty(sql)