//
// AlaSQL OrientDB compatibility plugin
// (c) 2015, Andrey Gershun
//
var yy = alasql.yy;