if (alasql.options.oracle) {
}
