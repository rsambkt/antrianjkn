if (typeof exports === 'object') {
	var assert = require('assert');
	var alasql = require('..');
}

describe('Test 75 - NULL, IS NULL', function() {
	//	it.skip('localStorage', function(done){
	//		done();
	//	});
});
