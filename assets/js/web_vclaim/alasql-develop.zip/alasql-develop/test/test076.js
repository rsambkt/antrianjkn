if (typeof exports === 'object') {
	var assert = require('assert');
	var alasql = require('..');
}

describe('Test 76 - Phone Gap', function() {
	//	it.skip('localStorage', function(done){
	//		done();
	//	});
});
