if (typeof exports === 'object') {
	var assert = require('assert');
	var alasql = require('..');
}

describe('Test 69 - CSV and TAB database', function() {
	//	it.skip('localStorage', function(done){
	//		done();
	//	});
});
