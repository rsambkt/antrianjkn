if (typeof exports === 'object') {
	var assert = require('assert');
	var alasql = require('..');
}

describe('Test 58 - Indices', function() {
	/*	it('SELECT - CREATE INDEX "', function(done){
		var test1 = [{a:1},{a:2},{a:3},{a:4}];
		alasql("DROP TABLE IF EXISTS test1");
		alasql("CREATE TABLE test1 (a INT)");
		alasql("SELECT * INTO test1 FROM ?", [test1]);
		alasql("CREATE INDEX test1a ON test1(a)");
		done();
	});

	it('SELECT - CREATE INDEX "', function(done){
		var test2 = [{a:1,b:1},{a:2,b:1},{a:3,b:3},{a:4,b:4}];
		alasql("DROP TABLE IF EXISTS test2");
		alasql("CREATE TABLE test2 (a INT, b INT)");
		alasql("SELECT * INTO test2 FROM ?", [test2]);
		alasql("INSERT INTO test2 VALUES (5,5), (5,1), (5,2)");

		alasql("CREATE INDEX test2ab ON test2(a,b)");
		alasql("INSERT INTO test2 VALUES (3,1), (3,2), (3,4)");
		alasql("INSERT INTO test2 VALUES (1,1), (2,2), (3,3)");
		done();
	});
	it('SELECT - DROP INDEX "', function(done){
		alasql("DROP INDEX test1a")
		alasql("DROP INDEX test1ab")
		done();
	});
*/
});
