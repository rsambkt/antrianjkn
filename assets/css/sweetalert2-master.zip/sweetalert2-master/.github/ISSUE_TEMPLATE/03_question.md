---
name: Question
about: Ask a question
labels:

---

Please post your question to StackOverflow: https://stackoverflow.com/questions/ask
Make sure to add the `sweetalert2` tag to the question.

Thank you.

---

Has SweetAlert2 helped you create an amazing application? You can show your support by making a donation:
- PayPal: https://www.paypal.me/limonte
- Bitcoin: `12BxefvPMtHePgfPRDL1SaZYSG4GwQmWoP`
- Ether: `0x36e2b10666e2c0dc343901895ba3697b5d3214d1`
- Bitcoin Cash: `qqxs402qszgwuue00gwxw996lzhpa8up2unqm0y46g`
- Stellar: `GBRS5KGFJO4OBUGW3TRQBIVXTM5YDS53DOSHGA3LKVE2YXKVKNVDONBP`
