---
name: Feature request
about: Wouldn’t it be nice if SweetAlert2 could ...
labels:

---

## New feature motivation

<!-- Describe the context, the use-case and the advantages of the feature request. -->

## New feature description

<!-- Optionally describe the functional changes that would have to be made in SweetAlert2. -->

## New feature implementation

<!-- Optionally describe the technical changes to be made in SweetAlert2. -->


---

Has SweetAlert2 helped you create an amazing application? You can show your support by making a donation:
- PayPal: https://www.paypal.me/limonte
- Bitcoin: `12BxefvPMtHePgfPRDL1SaZYSG4GwQmWoP`
- Ether: `0x36e2b10666e2c0dc343901895ba3697b5d3214d1`
- Bitcoin Cash: `qqxs402qszgwuue00gwxw996lzhpa8up2unqm0y46g`
- Stellar: `GBRS5KGFJO4OBUGW3TRQBIVXTM5YDS53DOSHGA3LKVE2YXKVKNVDONBP`
